// Get the current version of the Gluon branch.
module.exports = {
  version: 'v3.0.1'
}
