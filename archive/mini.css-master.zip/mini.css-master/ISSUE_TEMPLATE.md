* Framework Version:
* Flavor used:
* Operating System/Browser:
* Code to reproduce:
* Screenshots:
* Bug description:
* Additional information (Optional):

[Note]: # (Please describe what the bug is, what component/module causes it and how it differs from expected/intended behavior)
[Note]: # (Include screenshots of the reported bug whenever possible to best clarify)
[Note]: # (Always try to include code to reproduce the problem, as well as system specifications to make tracking easier)
[Note]: # (Codepen links, additional information, suggestions, articles etc. are greatly appreciated)
[Note]: # (If you want to suggest a feature or your issue doesn't classify as a bug report, please do not use this template)
