---
name: Question (QUESTIONS MUST BE ASKED ON STACK OVERFLOW!!! DO NOT CREATE AN ISSUE!!!)
about: Please ask questions on Stack Overflow, NOT on GitHub
title: ''
labels: Invalid, Question - Ask On Stack Overflow
assignees: ''

---

Please ask questions on www.stackoverflow.com the issues list is now reserved for feature requests and bug reports.

Questions asked in the issue list will be automatically closed!
