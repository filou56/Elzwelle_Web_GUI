module.exports = {
  id: '',
  title: '',
  keywords: [],
  description: '',
  example: '',
  samples: [],
  notes: [],
  customization: [],
  modifiers: [],
  dos: [],
  donts: []
}

/*
  Modifiers:
  {
    title : '',
    description: '',
    example: '',
    samples: []
  }
  Dos/Donts:
  {
    description: '',
    sample: ''
  }
*/
