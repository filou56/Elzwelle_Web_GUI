var premadeFlavors = require('./premadeFlavors');
var buildYourOwn = require('./buildYourOwnFlavor');
var flavorTools = require('./flavorTools');

module.exports = [premadeFlavors, flavorTools, buildYourOwn]
